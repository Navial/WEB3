import React from 'react';

const About = () => {
  return <div>About this site</div>;
};

export default About;
